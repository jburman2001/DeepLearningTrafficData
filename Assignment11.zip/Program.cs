﻿/*Class: CSE 1322L
Section: 01 C#
Term: Spring 2020
Instructor: Peter Adeojo
Name: Kaitlyn Anderson
Lab#: Assignment 11
*/
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace Assignment11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a filename: ");
            string fileName = Console.ReadLine();
            try
            {
                WordCount(fileName);
            }
            catch(FileNotFoundException ex)
            {
                Console.WriteLine("File error: " + fileName + " (No such file or directory");
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception thrown: " + e.Message);
            }
            finally
            {
                
            }
        }

        public static void WordCount(string fileName)
        {
            List<string> lines = new List<string>();
            List<string> words = new List<string>();
            List<char> letters = new List<char>();
            

            StreamReader sr = File.OpenText(fileName + ".txt");
            string s;
            while((s = sr.ReadLine()) != null)
            {
                lines.Add(s);
                //words = s.Split(' ').ToList();
                string[] tempStr = s.Split(' ');
                foreach(string f in tempStr)
                {
                    words.Add(f);
                }
                char[] tempChr = s.ToCharArray();
                foreach(char c in tempChr)
                {
                    if(c != ' ' && c != ',' && c != '.')
                    {
                        letters.Add(c);
                    }
                }
            }
            Console.WriteLine("Lines: " + lines.Count + "\nWords: " + words.Count + "\nChars: " + letters.Count);
            sr.Close();
        }
    }
}
